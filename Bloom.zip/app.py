from distutils.log import debug
import json
from flask_cors import CORS
from flask import Flask, jsonify, request

app = Flask(__name__)
CORS(app)
newsfeed = [
    {
    "Garden Name" : "Riverside Residential Gardening Club" ,
    "Location" : "250 Riverside Avenue ",
    "Description" : "A place for people to show off and discuss backyard gardens."
    },
    {
    "Garden Name" : "Lettuce Be Thankful" ,
    "Location" : "1234 Romaine Lane",
    "Description" : "A group for the best lettuce and other veggie grows in Riverside! Tips and tricks allowed on this page. Everyone is welcome, don’t be a stranger!"
    },
    {
    "Garden Name" : "Good Chives Only" ,
    "Location" : "5678 Scallion Street",
    "Description" : "We’re not crying because we’re sad. We’re crying over how GREAT these chives, onions, and garlic are in our local garden!"
    }
]

appfeed = [
{"Title" :"New Seeds",
"Description" : "The Club has gotten ahold of some seeds and you can get them either by payment of by our rafel",
"Date":"20, May, 1750",
"Author":"Tom Butter Warts"},

{"Title" :"How To Better growth",
"Description" : "Having Biodegrable substains can really help and a compos as well, so if you have peel, left overs, or dead body, remeber plants can really get alot of nutrians from them.",
"Date":"5, Aprile, 250BCE",
"Author":"Mark Son of John"},

{"Title" :"Something Something",
"Description" : "The Club has something of something",
"Date":"20, May, ?????",
"Author":"Someone I don't, What am I an author or something"}

]


newsfeed.append({"title": "thing", "author": "ryan"})
appfeed.append({"Title":"Da_news", "description":"the_juice", "date":"D/M/Y"})

@app.route('/')
def index():
    return "Home page"

@app.route('/post' )
def add():
    print (request.args.get("title"))
    newsfeed.append({"title": request.args.get("title"), "author": request.args.get("ryan")})
    newsfeed.append({"title": "thing", "author": "ryan"})
    return "Add as a string"

@app.route('/app/feed')
def getfeed():
    print(request.args.get("Title","description","date"))
    appfeed.append({"title": request.args.get("Title"), "description": request.args.get("discription"),"Date":request.args.get("ryan")})
    return jsonify(appfeed)

#Note add post method instead and request data from . f
#From jason, have to talk about to team, try to figure it out
