function clicked(){
  let user_input = document.getElementById("input").value;
    let url = '  https://c820-2601-646-9600-6750-75f7-23e2-d6c5-8ab9.ngrok.io/post?title='+user_input+'&author=Run';
  
  fetch(url).then(res => res.json()).then(response => {
    document.getElementById('display').innerHTML =JSON.stringify(response);
  });
}
function appfeed(){
  let feed = document.getElementById("appfeed").value;
    let url = '  https://c820-2601-646-9600-6750-75f7-23e2-d6c5-8ab9.ngrok.io/app/feed;
  
  fetch(url).then(res => res.json()).then(response => {
    document.getElementById('appfeed').innerHTML =JSON.stringify(response);
  });
function 
}

function user(){
  let feed = document.getElementById("feed").value;
    let url = '  https://c820-2601-646-9600-6750-75f7-23e2-d6c5-8ab9.ngrok.io/feed;
  
  fetch(url).then(res => res.json()).then(response => {
    document.getElementById('display').innerHTML =JSON.stringify(response);
  });
function 
}